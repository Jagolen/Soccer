import pandas as pd
import matplotlib.pyplot as plt
import pickle
from epv.processor import feature_creation
import epv.ml_builder as bld
import sklearn.metrics as skm
from mplsoccer import Pitch
import numpy as np

def show_arrows(df):
    df['start_x_mod'] = df['start_x'] * 1.05
    df['end_x_mod'] = df['end_x'] * 1.05
    df['start_y_mod'] = df['start_y'] * 0.68
    df['end_y_mod'] = df['end_y'] * 0.68
    pitch = Pitch(line_color='black',pitch_type='custom', pitch_length=105, pitch_width=68, line_zorder = 2)
    fig, ax = pitch.grid()
    for i, row in df.iterrows():
        value = row["prob"]
        #adjust the line width so that the more passes, the wider the line
        line_width = (value)
        #get angle
        if row.dx != 0:
            angle = np.arctan((row.end_y_mod - row.start_y_mod)/(row.end_x_mod - row.start_x_mod))*180/np.pi
        else:
            angle = np.arctan((row.end_y_mod - row.start_y_mod)/0.000001)*180/np.pi

        #plot lines on the pitch
        pitch.arrows(row.start_x_mod, row.start_y_mod, row.end_x_mod, row.end_y_mod,
                            alpha=0.6, width=line_width, zorder=2, color="blue", ax = ax["pitch"])
    plt.show()



import pandas as pd
import matplotlib.pyplot as plt
import pickle
from epv.processor import feature_creation
import epv.ml_builder as bld
import sklearn.metrics as skm
from mplsoccer import Pitch
import numpy as np

df = pd.read_parquet("opta/data/pass_xg.parquet")
lin_model = pickle.load(open("opta/models/EPV_Lin_Model.sav", "rb"))
log_model = pickle.load(open("opta/models/EPV_Log_Model.sav", "rb"))

# Only Open play passes
df = df[df['chain_type'] == 'open_play']

# Only passes from attacking possessions
df = df[df['possession_team_id'] == df['team_id']]

# Only successful passes
df = df[(df['outcome'])]

df = feature_creation(df)

df['const'] = 1
df = bld.__add_features(df, lin_model.model.exog_names + log_model.model.exog_names)
df['prob_log'] = log_model.predict(df[log_model.model.exog_names])
df['prob_lin'] = lin_model.predict(df[lin_model.model.exog_names])
df['prob'] = df['prob_log'] * df['prob_lin']

df = df[df['prob'] > 0.15]
df = df[df['start_x'] > 0]
df = df[df['start_y'] > 0]
df = df[df['end_x'] > 0]
df = df[df['end_y'] > 0]
df['dx'] = df["end_x"] - df["start_x"]
df['dy'] = df["end_y"] - df["start_y"]
df['start_x_mod'] = df['start_x'] * 1.05
df['end_x_mod'] = df['end_x'] * 1.05
df['start_y_mod'] = df['start_y'] * 0.68
df['end_y_mod'] = df['end_y'] * 0.68
x = df["start_x"].to_numpy()
y = df["start_y"].to_numpy()
dx = df["dx"].to_numpy()
dy = df["dy"].to_numpy()
prob = df["prob"].to_numpy()

print(dx)

plt.quiver(x, y, dx, dy)
plt.xlim([0, 100])
plt.ylim([0, 100])
plt.title("All data")
plt.show()

max_value = df["prob"].max()

pitch = Pitch(line_color='black',pitch_type='custom', pitch_length=105, pitch_width=68, line_zorder = 2)
fig, ax = pitch.grid()
for i, row in df.iterrows():
    value = row["prob"]
    #adjust the line width so that the more passes, the wider the line
    line_width = (value / max_value * 2)
    #get angle
    if row.dx != 0:
        angle = np.arctan((row.end_y_mod - row.start_y_mod)/(row.end_x_mod - row.start_x_mod))*180/np.pi
    else:
        angle = np.arctan((row.end_y_mod - row.start_y_mod)/0.000001)*180/np.pi

    #plot lines on the pitch
    if row.prob != max_value:
        pitch.arrows(row.start_x_mod, row.start_y_mod, row.end_x_mod, row.end_y_mod,
                            alpha=0.6, width=line_width, zorder=2, color="blue", ax = ax["pitch"])
    else:
        pitch.arrows(row.start_x_mod, row.start_y_mod, row.end_x_mod, row.end_y_mod,
                            alpha=1, width=line_width, zorder=2, color="red", ax = ax["pitch"])        
    #annotate max text
        ax["pitch"].text((row.start_x_mod+row.end_x_mod-8)/2, (row.start_y_mod+row.end_y_mod-4)/2, str(value)[:5], fontweight = "bold", color = "red", zorder = 4, fontsize = 20, rotation = int(angle))
plt.show()


